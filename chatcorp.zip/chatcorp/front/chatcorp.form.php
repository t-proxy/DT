<?php

include('../../../inc/includes.php');

if ($_SESSION["glpiactiveprofile"]["interface"] == "central") {
   Html::header("API Chat Corp", $_SERVER['PHP_SELF'], "plugins", "pluginchatcorpchatcorp", "");
} else {
   Html::helpHeader("API Chat Corp", $_SERVER['PHP_SELF']);
}

if (!isset($_SESSION['glpiname'])) {
   echo "<center><h3>Você não tem permissão para acessar este recurso!</h3></center>";
   die;
}

$chatcorp = new PluginChatcorpChatcorp();
$clear_form = false;
$_POST['token'] = isset($_POST['token']) ? str_replace(' ', '', $_POST['token']) : '';

if (isset($_POST["add"])) {
   if (strlen($_POST['token']) == 36) {
      $_POST['number'] = $chatcorp->setNumber($_POST['token']);
   }

   $newID = $chatcorp->add($_POST);
   Html::redirect(Toolbox::getItemTypeFormURL('PluginChatcorpChatcorp') . "?id=$newID");
} else if (isset($_POST["update"]) || isset($_POST["validate"])) {
   $id = $_POST['id'];
   $_POST['entities_id'] = isset($_POST['entities_id']) ? $_POST['entities_id'] : null;

   if (isset($_POST["validate"]) && strlen($_POST['token']) == 36) {
      $_POST['number'] = $chatcorp->setNumber($_POST['token']);
   }

   if (!isset($_POST['number']) || strlen($_POST['token']) != 36) {
      $_POST['number'] = '';
      $_POST['entities_id'] = null;
   }

   $chatcorp->setEntities($id, $_POST['entities_id']);

   $chatcorp->update($_POST);

   Html::redirect(Toolbox::getItemTypeFormURL('PluginChatcorpChatcorp') . "?id=$id");
} else if (isset($_POST["delete"])) {
   $chatcorp->delete($_POST);
   $chatcorp->redirectToList();
} else if (isset($_POST["testmessage"])) {
   $msg = $chatcorp->sendTest($_POST['token'], $_POST['mobilenumber'])
      ? 'Mensagem de teste enviada com sucesso!'
      : 'Ocorreu um erro!';
   Session::addMessageAfterRedirect($msg);
   Html::back();
} else if (isset($_POST["testnotification"])) {
   $notificationwhatsapp = new PluginChatcorpNotificationWhatsappSetting();

   $options = [
      '_itemtype'                   => 'PluginChatcorpNotificationEventWhatsapp',
      '_items_id'                   => 0,
      '_notificationtemplates_id'   => 0,
      '_entities_id'                => 0,
      'fromname'                    => Session::getLoginUserID(),
      'subject'                     => "[+] Adicionado na fila -> A notificação será enviada para: {$_POST['mobilenumber']}",
      'content_text'                   => "Notificação de teste do Chat Corp",
      'recipient'                   => $_POST['mobilenumber'],
      'sender'                      => $_POST['number'],
   ];

   (new PluginChatcorpNotificationWhatsapp())->sendNotification($options);

   Session::addMessageAfterRedirect('Notificação de teste adicionada na fila de envio!');
   Html::back();
}

$chatcorp->display($_GET);

Html::footer();
