<?php

class PluginChatcorpNotificationWhatsapp implements NotificationInterface
{
    static function check($value, $options = [])
    {
        //Does nothing, but we could check if $value is actually what we expect as a phone number to send Chatcorp.
        return true;
    }

    static function testNotification()
    {
        return true;
    }

    function sendNotification($options = array())
    {
        $data = array();
        $data['itemtype']                             = $options['_itemtype'];
        $data['items_id']                             = $options['_items_id'];
        $data['notificationtemplates_id']             = $options['_notificationtemplates_id'];
        $data['entities_id']                          = $options['_entities_id'];

        $data['sendername']                           = '';
        $data['sender']                               = $options['sender'];

        $data['name']                                 = $options['subject'];
        $data['body_text']                            = $options['content_text'];

        $data['recipient']                            = $options['recipient'];
        $data['recipientname']                        = $options['recipientname'];

        $data['mode'] = PluginChatcorpNotificationWhatsappSetting::MODE_WHATSAPP;

        $notificationqueue = new QueuedNotification();

        // Adicionar notificação na notificationqueue
        if (!$notificationqueue->add(Toolbox::addslashes_deep($data))) {
            Session::addMessageAfterRedirect(__('Erro ao adicionar a notificação na fila'), true, ERROR);
            return false;
        } else {
            //TRANS to be written in logs %1$s is the to email / %2$s is the subject of the mail
            // Adicionar notificação no log do GLPI
            Toolbox::logInFile(
                "notification",
                sprintf(
                    __('%1$s: %2$s'),
                    sprintf(
                        __('A whatsapp notification to %s was added to queue'),
                        $options['to']
                    ),
                    $options['subject'] . "\n"
                )
            );
        }

        return true;
    }
}
