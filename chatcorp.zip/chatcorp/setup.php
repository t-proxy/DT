<?php

// Habilitar cron do glpi
define('GLPI_SYSTEM_CRON', true);

/**
 * Função de setup
 */
function plugin_version_chatcorp()
{
    return array(
        'name'           => "API Chat Corp",
        'version'        => '1.5.6',
        'author'         => "<a href='https://dtnetwork.com.br/plugin-whatsapp-para-glpi-chat-corp/' target='_blank'>DT Network</a>",
        'license'        => 'GPLv3+',
        'homepage'       => 'https://dtnetwork.com.br'
    );
}

/**
 * Função de inicialização
 */
function plugin_init_chatcorp()
{
    global $PLUGIN_HOOKS;
    $plugin = new Plugin();

    // Ativar botão de habilitar plugin
    $PLUGIN_HOOKS['csrf_compliant']['chatcorp'] = true;

    // Definir página de configuração
    /* $PLUGIN_HOOKS['config_page']['chatcorp'] = '../../front/config.form.php?forcetab=PluginChatcorpConfig$1'; */
    // Plugin::registerClass('PluginChatcorpConfig', array('addtabon' => array('Config')));

    $_SESSION["glpi_plugin_chatcorp_profile"]['chatcorp'] = 'w';

    // Adicionar botão na aba Plugins
    if (isset($_SESSION["glpi_plugin_chatcorp_profile"])) {
        $PLUGIN_HOOKS['menu_toadd']['chatcorp'] = ['plugins' => 'PluginChatcorpChatcorp'];
    }

    if ($plugin->isActivated('chatcorp')) {
        Notification_NotificationTemplate::registerMode(
            PluginChatcorpNotificationWhatsappSetting::MODE_WHATSAPP, //mode itself
            __('API Chatcorp', 'plugin_chatcorp'),             //label
            'chatcorp'                                    //plugin name
        );
    }
}

/**
 * Verificar versão
 */
function plugin_chatcorp_check_prerequisites()
{
    $v = explode('.', GLPI_VERSION);
    $version = "{$v[0]}.{$v[1]}";
    if ($version >= 9.4) {
        return true;
    } else {
        echo "GLPI version NOT compatible. Requires GLPI >= 9.4";
    }
}

/**
 * Função para verificar configurações
 *
 * @return boolean
 */
function plugin_chatcorp_check_config()
{
    // Ao retornar false o glpi exibe uma mensagem de que o plugin deve ser configurado
    return true;
}
