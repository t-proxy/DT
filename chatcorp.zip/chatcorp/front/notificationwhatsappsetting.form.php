<?php

include('../../../inc/includes.php');

Session::checkRight("config", UPDATE);
$notificationwhatsapp = new PluginChatcorpNotificationWhatsappSetting();

if (!empty($_POST["test"])) {
    $options = [
        '_itemtype'                   => 'PluginChatcorpNotificationEventWhatsapp',
        '_items_id'                   => 0,
        '_notificationtemplates_id'   => 0,
        '_entities_id'                => 0,
        'fromname'                    => Session::getLoginUserID(),
        'subject'                     => "[+] Adicionado na fila -> Notificação enviada para: {$_POST['phone_number']}",
        'content_text'                => "Notificação de teste",
        'to'                          => $_POST['phone_number']
    ];

    (new PluginChatcorpNotificationWhatsapp())->sendNotification($options);

    Html::back();
} else if (!empty($_POST["update"])) {
    $config = new Config();
    $config->update($_POST);
    Html::back();
}

Html::header(Notification::getTypeName(Session::getPluralNumber()), $_SERVER['PHP_SELF'], "config", "notification", "config");

$notificationwhatsapp->display(['id' => 1]); // Exibir formulário de notificação

Html::footer();
