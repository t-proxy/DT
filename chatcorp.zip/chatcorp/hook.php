<?php

/**
 * Função de instalação
 *
 * @return boolean
 */
function plugin_chatcorp_install()
{
    global $DB;

    $charset = 'utf8';
    $collate = 'utf8_unicode_ci';
    $sign = '';

    if (GLPI_VERSION >= 10) {
        $charset = 'utf8mb4';
        $collate = 'utf8mb4_general_ci';
        $sign = 'UNSIGNED';
    }

    // $migration = new Migration(100);

    if (!$DB->tableExists("glpi_plugin_chatcorp_chatcorps")) {
        // Criar tabela do plugin
        $query = "CREATE TABLE `glpi_plugin_chatcorp_chatcorps` (
            `id` INT {$sign} NOT NULL auto_increment,
            `token` VARCHAR(36) NOT NULL,
            `number` VARCHAR(20) NULL,
            `description` VARCHAR(255) NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=$charset COLLATE=$collate";

        $DB->queryOrDie($query, $DB->error());
    }

    if (!$DB->tableExists("glpi_plugin_chatcorp_entities")) {
        // Criar tabela das entidades
        $query = "CREATE TABLE `glpi_plugin_chatcorp_entities` (
            `id` INT {$sign} NOT NULL auto_increment,
            `entity_id` INT {$sign} NOT NULL DEFAULT '0',
            `wts_id` INT {$sign} NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`),
            CONSTRAINT `ccorp_wts_id` FOREIGN KEY (`wts_id`) REFERENCES `glpi_plugin_chatcorp_chatcorps` (`id`) ON UPDATE CASCADE ON DELETE CASCADE
        ) ENGINE=InnoDB  DEFAULT CHARSET=$charset COLLATE=$collate";
    } else {
        $query = "ALTER TABLE `glpi_plugin_chatcorp_entities` DROP FOREIGN KEY IF EXISTS `ccorp_wts_id`";

        $DB->queryOrDie($query, $DB->error());

        $query = "ALTER TABLE `glpi_plugin_chatcorp_entities`
        ADD CONSTRAINT `ccorp_wts_id` FOREIGN KEY
        (`wts_id`) REFERENCES `glpi_plugin_chatcorp_chatcorps` (`id`) ON UPDATE CASCADE ON DELETE CASCADE;";
    }

    $DB->queryOrDie($query, $DB->error());

    // TODO, estou fazendo esse drop table na tabela de mensagens para incluir um campo de ticket, se algum cliente tiver uma versão antiga do plugin, poderia dar algum problema, essa tabela salva mensagens enviadas...
    $DB->queryOrDie("DROP TABLE IF EXISTS glpi_plugin_chatcorp_messages;", $DB->error());

    if (!$DB->tableExists("glpi_plugin_chatcorp_messages")) {
        // Criar tabela de envios
        $query = "CREATE TABLE `glpi_plugin_chatcorp_messages` (
            `id` INT {$sign} NOT NULL auto_increment,
            `message_id` VARCHAR(255) NOT NULL,
            `ticket_id` INT {$sign} NOT NULL,
            PRIMARY KEY (`id`),
            CONSTRAINT `ccorp_ticket_id` FOREIGN KEY (`ticket_id`) REFERENCES `glpi_tickets` (`id`) ON UPDATE CASCADE ON DELETE CASCADE
        ) ENGINE=InnoDB  DEFAULT CHARSET=$charset COLLATE=$collate";
    } else {
        $query = "ALTER TABLE `glpi_plugin_chatcorp_messages` DROP FOREIGN KEY IF EXISTS `ccorp_ticket_id`";

        $DB->queryOrDie($query, $DB->error());

        $query = "ALTER TABLE `glpi_plugin_chatcorp_messages`
        ADD CONSTRAINT `ccorp_ticket_id` FOREIGN KEY
        (`ticket_id`) REFERENCES `glpi_tickets` (`id`) ON UPDATE CASCADE ON DELETE CASCADE;";
    }

    $DB->queryOrDie($query, $DB->error());

    if ($DB->tableExists("glpi_requesttypes")) {
        // Criar tabela de envios
        $iterator = $DB->request("SELECT * FROM `glpi_requesttypes` WHERE COMMENT = 'WhatsApp';");

        if (sizeof($iterator) == 0) {
            $query = "INSERT INTO `glpi_requesttypes`
                              (`name`, `comment`)
                       VALUES ('WhatsApp', 'WhatsApp');";
            $DB->queryOrDie($query, $DB->error());
        }
    }


    $iterator = $DB->request("SELECT * FROM glpi_notifications_notificationtemplates WHERE mode = 'whatsapp'");

    if (sizeof($iterator) == 0) {
        notificationTemplates("create"); // Criando templates de notificação
    }

    Config::setConfigurationValues('core', ['notifications_whatsapp' => 1]);

    // $migration->executeMigration();

    return true;
}

/**
 * Função de desinstalação
 *
 * @return boolean
 */
function plugin_chatcorp_uninstall()
{
    $config = new Config();

    $config->deleteConfigurationValues('core', ['notifications_whatsapp']);

    return true;
}

function plugin_chatcorp_giveItem($type, $ID, $data, $num)
{
    $searchopt = &Search::getOptions($type);

    $table = $searchopt[$ID]["table"];
    $field = $searchopt[$ID]["field"];

    switch ($table . '.' . $field) {
        case "glpi_plugin_chatcorp_chatcorps.token":
            $out = "<a href='" . Toolbox::getItemTypeFormURL('PluginChatcorpChatcorp') . "?id=" . $data['id'] . "'>";
            $out .= $data[$num][0]['name'];

            $out .= "</a>";
            return $out;
    }

    return "";
}

/**
 * Função para criar/excluir notificações padrão
 *
 * @author Ryan
 */
function notificationTemplates($act)
{
    global $DB;
    switch ($act) {
        case "create":
            $templates = [
                "Chat Corp: Novo chamado" => [
                    "type"          => "Ticket",
                    "event"         => "new",
                    "targets"        => [
                        1 => [3]
                    ],
                    "subject"       => "Novo chamado",
                    "content_text"  => 'Olá *##ticket.authors##* seu chamado _##ticket.id##_ foi aberto com sucesso!

Segue abaixo as informações:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Descrição:* ##ticket.content##

*Status:* ##ticket.status##

*Para interagir com ele basta clicar no link:* ##ticket.url##
*Para adicionar um acompanhamento, use o recurso de resposta do WhatsApp nesta mensagem.*

Obrigado'
                ],
                "Chat Corp: Novo acompanhamento" => [
                    "type"          => "Ticket",
                    "event"         => "add_followup",
                    "targets"        => [
                        1 => [3]
                    ],
                    "subject"       => "Novo acompanhamento",
                    "content_text"  => 'Olá *##ticket.authors##* seu chamado _##ticket.id##_ foi respondido!

Segue abaixo as informações:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Informações adicionadas:*

##FOREACHfollowups##

[_##followup.date##_] *##followup.author##* respondeu: ##followup.description##

##ENDFOREACHfollowups##

*Status:* ##ticket.status##

*Para interagir com ele basta clicar no link:* ##ticket.url##
*Para adicionar um acompanhamento, use o recurso de resposta do WhatsApp nesta mensagem.*

Obrigado'
                ],
                "Chat Corp: Chamado encerrado" => [
                    "type"          => "Ticket",
                    "event"         => "closed",
                    "targets"        => [
                        1 => [3]
                    ],
                    "subject"       => "Chamado encerrado",
                    "content_text"  => 'Olá *##ticket.authors##* seu chamado _##ticket.id##_ foi encerrado!

Segue abaixo as informações:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Status:* ##ticket.status##

Muito obrigado por utilizar nossos serviços'
                ],
                "Chat Corp: Aguardando validação" => [
                    "type"          => "Ticket",
                    "event"         => "validation",
                    "targets"        => [
                        1 => [3]
                    ],
                    "subject"       => "Aguardando validação",
                    "content_text"  => 'Olá *##ticket.authors##* seu chamado _##ticket.id##_ foi solucionado e aguarda a sua validação!

Segue abaixo as informações:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Informações da solução:* ##ticket.solution.description##

*Status:* ##ticket.status##

*Para aprovar ou reprovar a solução, clique no link:* ##ticket.urlapprove##
*Para adicionar um acompanhamento, use o recurso de resposta do WhatsApp nesta mensagem.*

Obrigado'
                ],
                "Chat Corp: Chamado solucionado" => [
                    "type"          => "Ticket",
                    "event"         => "solved",
                    "targets"        => [
                        1 => [3]
                    ],
                    "subject"       => "Chamado solucionado",
                    "content_text"  => 'Olá *##ticket.authors##* seu chamado _##ticket.id##_ foi solucionado em ##ticket.solvedate##!

Segue abaixo as informações:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Informações da solução:* ##ticket.solution.description##

*Status:* ##ticket.status##

*Para interagir com ele basta clicar no link:* ##ticket.url##

Obrigado'
                ],
                "Chat Corp: Pesquisa de satisfação" => [
                    "type"          => "Ticket",
                    "event"         => "satisfaction",
                    "targets"        => [
                        1 => [3]
                    ],
                    "subject"       => "Chamado solucionado",
                    "content_text"  => '⭐⭐⭐⭐⭐

Olá *##ticket.authors##* avalie o atendimento recebido referente ao seu chamado com os dados abaixo:

*Chamado:* ##ticket.id##
*Título:* ##ticket.title##
*Status:* ##ticket.status##

*Clique no link abaixo para avaliar o atendimento:*
##ticket.urlsatisfaction##

A sua avaliação é muito importante para nós.

Obrigado'
                ],
            ];

            foreach ($templates as $name => $notify) {
                $query_template = "INSERT INTO `glpi_notificationtemplates`
                          (`name`, `itemtype`, `date_mod`)
                   VALUES ('{$name}', '{$notify["type"]}', NOW())";

                $query_notify = "INSERT INTO `glpi_notifications`
                          (`name`, `itemtype`, `event`, `is_recursive`, `is_active`)
                   VALUES ('{$name}', '{$notify["type"]}', '{$notify["event"]}', 1, 1)";

                if (!method_exists($DB, "insertId")) {
                    $DB->queryOrDie($query_template, $DB->error());
                    $templateid = $DB->insert_id();
                    $DB->queryOrDie($query_notify, $DB->error());
                    $notificationid = $DB->insert_id();
                } else {
                    $DB->queryOrDie($query_template, $DB->error());
                    $templateid = $DB->insertId();
                    $DB->queryOrDie($query_notify, $DB->error());
                    $notificationid = $DB->insertId();
                }

                foreach ($notify['targets'] as $type => $target) {
                    foreach ($target as $items_id) {
                        $query = "INSERT INTO `glpi_notificationtargets`
                                  (`items_id`, `type`, `notifications_id`)
                           VALUES ($items_id, $type, '{$notificationid}')";
                        $DB->queryOrDie($query, $DB->error());
                    }
                }

                $query = "INSERT INTO `glpi_notifications_notificationtemplates`
                          (`notifications_id`, `notificationtemplates_id`, `mode`)
                   VALUES ('{$notificationid}', '{$templateid}', 'whatsapp')";
                $DB->queryOrDie($query, $DB->error());

                $query = "INSERT INTO `glpi_notificationtemplatetranslations`
                          (`notificationtemplates_id`, `subject`, `content_text`)
                   VALUES ('{$templateid}', '{$notify["subject"]}', '{$notify["content_text"]}')";
                $DB->queryOrDie($query, $DB->error());
            }

            break;
    }
}
